﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _P__JSON___Chuck_Norris_Jokes
{
    public class Categories
    {
        public string[] categories { get; set; }
    }

    public class JokeCall
    { 
        public string value { get; set; }
    }
}
